// ============================================================================
//
// Copyright (c) 2005-2009, Talend Inc.
//
// Ce code source a �t� g�n�r� automatiquement par Talend Integration Suite Team Edition
// / JobDesigner (CodeGenerator version 3.2.3.r35442).
// Vous pouvez trouver plus d'information sur les produits Talend sur www.talend.com.
// Vous pouvez distribuer ce code sous les termes de la licence GNU LGPL
// (http://www.gnu.org/licenses/lgpl.html).
//
// ============================================================================ 
package prime.ins_csv_in_ora_0_1;

import routines.DataOperation;
import routines.Mathematical;
import routines.Numeric;
import routines.Relational;
import routines.StringHandling;
import routines.TalendDataGenerator;
import routines.TalendDate;
import routines.TalendString;
import routines.system.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.math.BigDecimal;
import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ObjectOutputStream;
import java.io.ObjectInputStream;
import java.io.IOException;
import java.util.Comparator;

/**
 * Job: INS_CSV_IN_ORA Purpose: Job insertion in database oracle from CSV<br>
 * Description: created by HALLAM MOHAMED AMINE <br>
 * 
 * @author DARGES, Jean-Sebastien
 * @version 3.2.3.r35442
 * @status
 */
public class INS_CSV_IN_ORA {

	public final Object obj = new Object();
	// create and load default properties
	private java.util.Properties defaultProps = new java.util.Properties();

	// create application properties with default
	private class ContextProperties extends java.util.Properties {

		public ContextProperties(java.util.Properties properties) {
			super(properties);
		}

		public ContextProperties() {
			super();
		}

		public void synchronizeContext() {

			if (ENVIRONNEMENT_dossierTmp != null) {

				this.setProperty("ENVIRONNEMENT_dossierTmp",
						ENVIRONNEMENT_dossierTmp.toString());

			}

			if (ENVIRONNEMENT_repertoireGenerationRbm != null) {

				this.setProperty("ENVIRONNEMENT_repertoireGenerationRbm",
						ENVIRONNEMENT_repertoireGenerationRbm.toString());

			}

			if (ENVIRONNEMENT_repertoireInstallation != null) {

				this.setProperty("ENVIRONNEMENT_repertoireInstallation",
						ENVIRONNEMENT_repertoireInstallation.toString());

			}

			if (ENVIRONNEMENT_repertoireLogs != null) {

				this.setProperty("ENVIRONNEMENT_repertoireLogs",
						ENVIRONNEMENT_repertoireLogs.toString());

			}

			if (ENVIRONNEMENT_repertoireStockageSource != null) {

				this.setProperty("ENVIRONNEMENT_repertoireStockageSource",
						ENVIRONNEMENT_repertoireStockageSource.toString());

			}

			if (INTERFACE_codeService != null) {

				this.setProperty("INTERFACE_codeService", INTERFACE_codeService
						.toString());

			}

			if (INTERFACE_CODETG != null) {

				this.setProperty("INTERFACE_CODETG", INTERFACE_CODETG
						.toString());

			}

			if (INTERFACE_confFile != null) {

				this.setProperty("INTERFACE_confFile", INTERFACE_confFile
						.toString());

			}

			if (INTERFACE_CORRES != null) {

				this.setProperty("INTERFACE_CORRES", INTERFACE_CORRES
						.toString());

			}

			if (INTERFACE_dateDebut != null) {

				this.setProperty("INTERFACE_dateDebut", INTERFACE_dateDebut
						.toString());

			}

			if (INTERFACE_FILE != null) {

				this.setProperty("INTERFACE_FILE", INTERFACE_FILE.toString());

			}

			if (INTERFACE_moisPaie != null) {

				this.setProperty("INTERFACE_moisPaie", INTERFACE_moisPaie
						.toString());

			}

			if (INTERFACE_mv != null) {

				this.setProperty("INTERFACE_mv", INTERFACE_mv.toString());

			}

			if (INTERFACE_name != null) {

				this.setProperty("INTERFACE_name", INTERFACE_name.toString());

			}

			if (INTERFACE_params != null) {

				this.setProperty("INTERFACE_params", INTERFACE_params
						.toString());

			}

			if (INTERFACE_pckgName != null) {

				this.setProperty("INTERFACE_pckgName", INTERFACE_pckgName
						.toString());

			}

			if (INTERFACE_returnCode != null) {

				this.setProperty("INTERFACE_returnCode", INTERFACE_returnCode
						.toString());

			}

			if (INTERFACE_srcFileName != null) {

				this.setProperty("INTERFACE_srcFileName", INTERFACE_srcFileName
						.toString());

			}

			if (REHUCIT_TAMPON_Login != null) {

				this.setProperty("REHUCIT_TAMPON_Login", REHUCIT_TAMPON_Login
						.toString());

			}

			if (REHUCIT_TAMPON_Password != null) {

				this.setProperty("REHUCIT_TAMPON_Password",
						REHUCIT_TAMPON_Password.toString());

			}

			if (REHUCIT_TAMPON_Port != null) {

				this.setProperty("REHUCIT_TAMPON_Port", REHUCIT_TAMPON_Port
						.toString());

			}

			if (REHUCIT_TAMPON_Schema != null) {

				this.setProperty("REHUCIT_TAMPON_Schema", REHUCIT_TAMPON_Schema
						.toString());

			}

			if (REHUCIT_TAMPON_Server != null) {

				this.setProperty("REHUCIT_TAMPON_Server", REHUCIT_TAMPON_Server
						.toString());

			}

			if (REHUCIT_TAMPON_Sid != null) {

				this.setProperty("REHUCIT_TAMPON_Sid", REHUCIT_TAMPON_Sid
						.toString());

			}

		}

		public String ENVIRONNEMENT_dossierTmp;
		public String ENVIRONNEMENT_repertoireGenerationRbm;
		public String ENVIRONNEMENT_repertoireInstallation;
		public String ENVIRONNEMENT_repertoireLogs;
		public String ENVIRONNEMENT_repertoireStockageSource;
		public String INTERFACE_codeService;
		public String INTERFACE_CODETG;
		public String INTERFACE_confFile;
		public String INTERFACE_CORRES;
		public String INTERFACE_dateDebut;
		public String INTERFACE_FILE;
		public String INTERFACE_moisPaie;
		public String INTERFACE_mv;
		public String INTERFACE_name;
		public String INTERFACE_params;
		public String INTERFACE_pckgName;
		public String INTERFACE_returnCode;
		public String INTERFACE_srcFileName;
		public String REHUCIT_TAMPON_Login;
		public java.lang.String REHUCIT_TAMPON_Password;
		public String REHUCIT_TAMPON_Port;
		public String REHUCIT_TAMPON_Schema;
		public String REHUCIT_TAMPON_Server;
		public String REHUCIT_TAMPON_Sid;
	}

	private ContextProperties context = new ContextProperties();
	private final String jobVersion = "0.1";
	private final String jobName = "INS_CSV_IN_ORA";
	private final String projectName = "PRIME";
	public Integer errorCode = null;
	private String currentComponent = "";
	private final java.util.Map<String, Long> start_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Long> end_Hash = new java.util.HashMap<String, Long>();
	private final java.util.Map<String, Boolean> ok_Hash = new java.util.HashMap<String, Boolean>();
	private final java.util.Map<String, Object> globalMap = new java.util.HashMap<String, Object>();
	public final java.util.List<String[]> globalBuffer = new java.util.ArrayList<String[]>();

	LogCatcherUtils talendLogs_LOGS = new LogCatcherUtils();
	StatCatcherUtils talendStats_STATS = new StatCatcherUtils(
			"_6WdDIJWnEd-vi66pjGoMTg", "0.1");
	MetterCatcherUtils talendMeter_METTER = new MetterCatcherUtils(
			"_6WdDIJWnEd-vi66pjGoMTg", "0.1");

	private final java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
	private final java.io.PrintStream errorMessagePS = new java.io.PrintStream(
			new java.io.BufferedOutputStream(baos));

	public String getExceptionStackTrace() {
		errorMessagePS.flush();
		return baos.toString();
	}

	private class TalendException extends Exception {
		private java.util.Map<String, Object> globalMap = null;
		private Exception e = null;
		private String currentComponent = null;

		private TalendException(Exception e, String errorComponent,
				final java.util.Map<String, Object> globalMap) {
			this.currentComponent = errorComponent;
			this.globalMap = globalMap;
			this.e = e;
		}

		@Override
		public void printStackTrace() {
			if (!(e instanceof TalendException || e instanceof TDieException)) {
				globalMap.put(currentComponent + "_ERROR_MESSAGE", e
						.getMessage());
				System.err
						.println("Exception in component " + currentComponent);
			}
			if (!(e instanceof TDieException)) {
				if (e instanceof TalendException) {
					e.printStackTrace();
				} else {
					e.printStackTrace();
					e.printStackTrace(errorMessagePS);
				}
			}
			if (!(e instanceof TalendException)) {
				try {
					for (java.lang.reflect.Method m : this.getClass()
							.getEnclosingClass().getMethods()) {
						if (m.getName().compareTo(currentComponent + "_error") == 0) {
							m.invoke(INS_CSV_IN_ORA.this, new Object[] { e,
									currentComponent, globalMap });
							break;
						}
					}

					if (!(e instanceof TDieException)) {
						talendLogs_LOGS.addMessage("Java Exception",
								currentComponent, 6, e.getClass().getName()
										+ ":" + e.getMessage(), 1);
						talendLogs_LOGSProcess(globalMap);
					}
				} catch (java.lang.SecurityException e) {
					this.e.printStackTrace();
				} catch (java.lang.IllegalArgumentException e) {
					this.e.printStackTrace();
				} catch (java.lang.IllegalAccessException e) {
					this.e.printStackTrace();
				} catch (java.lang.reflect.InvocationTargetException e) {
					this.e.printStackTrace();
				} catch (TalendException e) {
					// do nothing
				}

			}
		}
	}

	public void tOracleConnection_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {
		end_Hash.put("tOracleConnection_1", System.currentTimeMillis());
		tOracleConnection_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tFileInputDelimited_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {
		end_Hash.put("tFileInputDelimited_1", System.currentTimeMillis());
		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tOracleOutput_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {
		end_Hash.put("tOracleOutput_1", System.currentTimeMillis());
		tFileInputDelimited_1_onSubJobError(exception, errorComponent,
				globalMap);
	}

	public void tOracleCommit_1_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {
		end_Hash.put("tOracleCommit_1", System.currentTimeMillis());
		tOracleCommit_1_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendLogs_LOGS_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {
		end_Hash.put("talendLogs_LOGS", System.currentTimeMillis());
		talendLogs_LOGS_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendLogs_FILE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {
		end_Hash.put("talendLogs_FILE", System.currentTimeMillis());
		talendLogs_LOGS_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendStats_STATS_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {
		end_Hash.put("talendStats_STATS", System.currentTimeMillis());
		talendStats_STATS_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendStats_FILE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {
		end_Hash.put("talendStats_FILE", System.currentTimeMillis());
		talendStats_STATS_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendMeter_METTER_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {
		end_Hash.put("talendMeter_METTER", System.currentTimeMillis());
		talendMeter_METTER_onSubJobError(exception, errorComponent, globalMap);
	}

	public void talendMeter_FILE_error(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {
		end_Hash.put("talendMeter_FILE", System.currentTimeMillis());
		talendMeter_METTER_onSubJobError(exception, errorComponent, globalMap);
	}

	public void tOracleConnection_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId()
				+ "", "FATAL", "", exception.getMessage(), ResumeUtil
				.getExceptionStackTrace(exception));

	}

	public void tFileInputDelimited_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId()
				+ "", "FATAL", "", exception.getMessage(), ResumeUtil
				.getExceptionStackTrace(exception));

	}

	public void tOracleCommit_1_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId()
				+ "", "FATAL", "", exception.getMessage(), ResumeUtil
				.getExceptionStackTrace(exception));

	}

	public void talendLogs_LOGS_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId()
				+ "", "FATAL", "", exception.getMessage(), ResumeUtil
				.getExceptionStackTrace(exception));

	}

	public void talendStats_STATS_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId()
				+ "", "FATAL", "", exception.getMessage(), ResumeUtil
				.getExceptionStackTrace(exception));

	}

	public void talendMeter_METTER_onSubJobError(Exception exception,
			String errorComponent, final java.util.Map<String, Object> globalMap)
			throws TalendException {

		resumeUtil.addLog("SYSTEM_LOG", "NODE:" + errorComponent, "", Thread
				.currentThread().getId()
				+ "", "FATAL", "", exception.getMessage(), ResumeUtil
				.getExceptionStackTrace(exception));

	}

	public void tOracleConnection_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tOracleConnection_1_SUBPROCESS_STATE", 0);

		String currentComponent = "";

		try {

			String currentMethodName = new Exception().getStackTrace()[0]
					.getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume

				/**
				 * [tOracleConnection_1 begin ] start
				 */

				ok_Hash.put("tOracleConnection_1", false);
				start_Hash.put("tOracleConnection_1", System
						.currentTimeMillis());
				currentComponent = "tOracleConnection_1";

				int tos_count_tOracleConnection_1 = 0;

				String url_tOracleConnection_1 = "jdbc:oracle:thin:@"
						+ context.REHUCIT_TAMPON_Server + ":"
						+ context.REHUCIT_TAMPON_Port + ":"
						+ context.REHUCIT_TAMPON_Sid;
				globalMap.put("connectionType_" + "tOracleConnection_1",
						"ORACLE_SID");

				String userName_tOracleConnection_1 = context.REHUCIT_TAMPON_Login;

				String password_tOracleConnection_1 = context.REHUCIT_TAMPON_Password;

				java.sql.Connection conn_tOracleConnection_1 = null;

				java.lang.Class.forName("oracle.jdbc.driver.OracleDriver");
				conn_tOracleConnection_1 = java.sql.DriverManager
						.getConnection(url_tOracleConnection_1,
								userName_tOracleConnection_1,
								password_tOracleConnection_1);

				conn_tOracleConnection_1.setAutoCommit(false);
				globalMap.put("host_" + "tOracleConnection_1",
						context.REHUCIT_TAMPON_Server);
				globalMap.put("port_" + "tOracleConnection_1",
						context.REHUCIT_TAMPON_Port);
				globalMap.put("dbname_" + "tOracleConnection_1",
						context.REHUCIT_TAMPON_Sid);

				globalMap.put("conn_" + "tOracleConnection_1",
						conn_tOracleConnection_1);
				globalMap.put("dbschema_" + "tOracleConnection_1",
						context.REHUCIT_TAMPON_Schema);
				globalMap.put("username_" + "tOracleConnection_1",
						context.REHUCIT_TAMPON_Login);
				globalMap.put("password_" + "tOracleConnection_1",
						context.REHUCIT_TAMPON_Password);

				/**
				 * [tOracleConnection_1 begin ] stop
				 */
				/**
				 * [tOracleConnection_1 main ] start
				 */

				currentComponent = "tOracleConnection_1";

				tos_count_tOracleConnection_1++;

				/**
				 * [tOracleConnection_1 main ] stop
				 */
				/**
				 * [tOracleConnection_1 end ] start
				 */

				currentComponent = "tOracleConnection_1";

				ok_Hash.put("tOracleConnection_1", true);
				end_Hash.put("tOracleConnection_1", System.currentTimeMillis());

				/**
				 * [tOracleConnection_1 end ] stop
				 */

				globalResumeTicket = true;

			}// end the resume

			if (resumeEntryMethodName == null || globalResumeTicket) {
				resumeUtil
						.addLog(
								"CHECKPOINT",
								"CONNECTION:SUBJOB_OK:tOracleConnection_1:OnSubjobOk",
								"", Thread.currentThread().getId() + "", "",
								"", "", "");
			}

			tFileInputDelimited_1Process(globalMap);

		} catch (Exception e) {

			throw new TalendException(e, currentComponent, globalMap);

		}

		globalMap.put("tOracleConnection_1_SUBPROCESS_STATE", 1);
	}

	public static class row1Struct implements
			routines.system.IPersistableRow<row1Struct> {
		final static byte[] commonByteArrayLock = new byte[0];
		static byte[] commonByteArray = new byte[0];

		public String NNE;

		public String getNNE() {
			return this.NNE;
		}

		public String ADECOD;

		public String getADECOD() {
			return this.ADECOD;
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock) {

				try {

					int length = 0;

					length = dis.readInt();
					if (length == -1) {
						this.NNE = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.NNE = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.ADECOD = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.ADECOD = new String(commonByteArray, 0, length);
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// String

				if (this.NNE == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.NNE.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.ADECOD == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.ADECOD.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");

			sb.append("NNE");
			sb.append("=");
			sb.append(String.valueOf(this.NNE));

			sb.append(", ");

			sb.append("ADECOD");
			sb.append("=");
			sb.append(String.valueOf(this.ADECOD));

			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row1Struct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2
						.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void tFileInputDelimited_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 0);

		String currentComponent = "";

		try {

			String currentMethodName = new Exception().getStackTrace()[0]
					.getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume

				row1Struct row1 = new row1Struct();

				/**
				 * [tOracleOutput_1 begin ] start
				 */

				ok_Hash.put("tOracleOutput_1", false);
				start_Hash.put("tOracleOutput_1", System.currentTimeMillis());
				currentComponent = "tOracleOutput_1";

				int tos_count_tOracleOutput_1 = 0;

				int nb_line_tOracleOutput_1 = 0;
				int nb_line_update_tOracleOutput_1 = 0;
				int nb_line_inserted_tOracleOutput_1 = 0;
				int nb_line_deleted_tOracleOutput_1 = 0;

				int deletedCount_tOracleOutput_1 = 0;
				int updatedCount_tOracleOutput_1 = 0;
				int insertedCount_tOracleOutput_1 = 0;

				boolean whetherReject_tOracleOutput_1 = false;

				java.sql.Connection conn_tOracleOutput_1 = null;

				// optional table
				String dbschema_tOracleOutput_1 = null;
				String tableName_tOracleOutput_1 = null;
				dbschema_tOracleOutput_1 = (String) globalMap
						.get("dbschema_tOracleConnection_1");
				conn_tOracleOutput_1 = (java.sql.Connection) globalMap
						.get("conn_tOracleConnection_1");

				int batchSize_tOracleOutput_1 = 10000;
				int batchSizeCounter_tOracleOutput_1 = 0;

				if (dbschema_tOracleOutput_1 == null
						|| dbschema_tOracleOutput_1.trim().length() == 0) {
					tableName_tOracleOutput_1 = "PRM_SARA_GRADE";
				} else {
					tableName_tOracleOutput_1 = dbschema_tOracleOutput_1 + "."
							+ "PRM_SARA_GRADE";
				}
				String insert_tOracleOutput_1 = "INSERT INTO "
						+ tableName_tOracleOutput_1
						+ " (NNE,ADECOD) VALUES (?,?)";

				java.sql.PreparedStatement pstmt_tOracleOutput_1 = conn_tOracleOutput_1
						.prepareStatement(insert_tOracleOutput_1);

				/**
				 * [tOracleOutput_1 begin ] stop
				 */

				/**
				 * [tFileInputDelimited_1 begin ] start
				 */

				ok_Hash.put("tFileInputDelimited_1", false);
				start_Hash.put("tFileInputDelimited_1", System
						.currentTimeMillis());
				currentComponent = "tFileInputDelimited_1";

				int tos_count_tFileInputDelimited_1 = 0;

				int nb_line_tFileInputDelimited_1 = 0;
				int footer_tFileInputDelimited_1 = 0;
				int totalLinetFileInputDelimited_1 = 0;
				int limittFileInputDelimited_1 = -1;
				int lastLinetFileInputDelimited_1 = -1;

				char fieldSeparator_tFileInputDelimited_1[] = null;

				// support passing value (property: Field Separator) by
				// 'context.fs' or 'globalMap.get("fs")'.
				if (((String) ";").length() > 0) {
					fieldSeparator_tFileInputDelimited_1 = ((String) ";")
							.toCharArray();
				} else {
					throw new IllegalArgumentException(
							"Field Separator must be assigned a char.");
				}

				char rowSeparator_tFileInputDelimited_1[] = null;

				// support passing value (property: Row Separator) by
				// 'context.rs' or 'globalMap.get("rs")'.
				if (((String) "\n").length() > 0) {
					rowSeparator_tFileInputDelimited_1 = ((String) "\n")
							.toCharArray();
				} else {
					throw new IllegalArgumentException(
							"Row Separator must be assigned a char.");
				}

				Object filename_tFileInputDelimited_1 = /**
				 * Start field
				 * tFileInputDelimited_1:FILENAME
				 */
				"C:/Documents and Settings/ole/Bureau/PRM_SARA_GRADE.csv"/**
				 * End
				 * field tFileInputDelimited_1:FILENAME
				 */
				;
				com.csvreader.CsvReader csvReadertFileInputDelimited_1 = null;

				if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {
					csvReadertFileInputDelimited_1 = new com.csvreader.CsvReader(
							(java.io.InputStream) filename_tFileInputDelimited_1,
							fieldSeparator_tFileInputDelimited_1[0],
							java.nio.charset.Charset.forName("ISO-8859-15"));
				} else {
					csvReadertFileInputDelimited_1 = new com.csvreader.CsvReader(
							new java.io.BufferedReader(
									new java.io.InputStreamReader(
											new java.io.FileInputStream(
													filename_tFileInputDelimited_1
															.toString()),
											"ISO-8859-15")),
							fieldSeparator_tFileInputDelimited_1[0]);
				}

				if ((rowSeparator_tFileInputDelimited_1[0] != '\n')
						&& (rowSeparator_tFileInputDelimited_1[0] != '\r'))
					csvReadertFileInputDelimited_1
							.setRecordDelimiter(rowSeparator_tFileInputDelimited_1[0]);

				csvReadertFileInputDelimited_1.setSkipEmptyRecords(true);
				csvReadertFileInputDelimited_1.setTextQualifier('"');
				csvReadertFileInputDelimited_1
						.setEscapeMode(com.csvreader.CsvReader.ESCAPE_MODE_DOUBLED);

				String[] rowtFileInputDelimited_1 = null;

				if (footer_tFileInputDelimited_1 > 0) {

					while (csvReadertFileInputDelimited_1.readRecord()) {
						rowtFileInputDelimited_1 = csvReadertFileInputDelimited_1
								.getValues();
						if (!(rowtFileInputDelimited_1.length == 1 && ("\015")
								.equals(rowtFileInputDelimited_1[0]))) {// empty
																		// line
																		// when
																		// row
																		// separator
																		// is
																		// '\n'

							totalLinetFileInputDelimited_1++;

						}

					}
					int lastLineTemptFileInputDelimited_1 = totalLinetFileInputDelimited_1
							- footer_tFileInputDelimited_1 < 0 ? 0
							: totalLinetFileInputDelimited_1
									- footer_tFileInputDelimited_1;
					if (lastLinetFileInputDelimited_1 > 0) {
						lastLinetFileInputDelimited_1 = lastLinetFileInputDelimited_1 < lastLineTemptFileInputDelimited_1 ? lastLinetFileInputDelimited_1
								: lastLineTemptFileInputDelimited_1;
					} else {
						lastLinetFileInputDelimited_1 = lastLineTemptFileInputDelimited_1;
					}

					csvReadertFileInputDelimited_1.close();

					if (filename_tFileInputDelimited_1 instanceof java.io.InputStream) {
						csvReadertFileInputDelimited_1 = new com.csvreader.CsvReader(
								(java.io.InputStream) filename_tFileInputDelimited_1,
								fieldSeparator_tFileInputDelimited_1[0],
								java.nio.charset.Charset.forName("ISO-8859-15"));
					} else {
						csvReadertFileInputDelimited_1 = new com.csvreader.CsvReader(
								new java.io.BufferedReader(
										new java.io.InputStreamReader(
												new java.io.FileInputStream(
														filename_tFileInputDelimited_1
																.toString()),
												"ISO-8859-15")),
								fieldSeparator_tFileInputDelimited_1[0]);
					}

					if ((rowSeparator_tFileInputDelimited_1[0] != '\n')
							&& (rowSeparator_tFileInputDelimited_1[0] != '\r'))
						csvReadertFileInputDelimited_1
								.setRecordDelimiter(rowSeparator_tFileInputDelimited_1[0]);
					csvReadertFileInputDelimited_1.setSkipEmptyRecords(true);
					csvReadertFileInputDelimited_1.setTextQualifier('"');
					csvReadertFileInputDelimited_1
							.setEscapeMode(com.csvreader.CsvReader.ESCAPE_MODE_DOUBLED);

				}

				int currentLinetFileInputDelimited_1 = 0;
				int outputLinetFileInputDelimited_1 = 0;

				while (limittFileInputDelimited_1 != 0
						&& csvReadertFileInputDelimited_1.readRecord()) {

					rowtFileInputDelimited_1 = csvReadertFileInputDelimited_1
							.getValues();

					if (rowtFileInputDelimited_1.length == 1
							&& ("\015").equals(rowtFileInputDelimited_1[0])) {// empty
																				// line
																				// when
																				// row
																				// separator
																				// is
																				// '\n'
						continue;
					}

					currentLinetFileInputDelimited_1++;
					if (currentLinetFileInputDelimited_1 < 1 + 1) {
						continue;
					}

					if (lastLinetFileInputDelimited_1 > -1
							&& currentLinetFileInputDelimited_1 > lastLinetFileInputDelimited_1) {
						break;
					}
					outputLinetFileInputDelimited_1++;
					if (limittFileInputDelimited_1 > 0
							&& outputLinetFileInputDelimited_1 > limittFileInputDelimited_1) {
						break;
					}

					row1 = null;
					boolean whetherReject_tFileInputDelimited_1 = false;
					row1 = new row1Struct();
					try {

						if (rowtFileInputDelimited_1.length == 1
								&& ("\015").equals(rowtFileInputDelimited_1[0])) {// empty
																					// line
																					// when
																					// row
																					// separator
																					// is
																					// '\n'

							row1.NNE = null;

							row1.ADECOD = null;

						} else {

							if (0 < rowtFileInputDelimited_1.length) {
								row1.NNE = rowtFileInputDelimited_1[0].trim();

							} else {
								row1.NNE = null;
							}

							if (1 < rowtFileInputDelimited_1.length) {
								row1.ADECOD = rowtFileInputDelimited_1[1]
										.trim();

							} else {
								row1.ADECOD = null;
							}

						}

					} catch (Exception e) {
						whetherReject_tFileInputDelimited_1 = true;
						System.err.println(e.getMessage());
						row1 = null;
					}

					/**
					 * [tFileInputDelimited_1 begin ] stop
					 */
					/**
					 * [tFileInputDelimited_1 main ] start
					 */

					currentComponent = "tFileInputDelimited_1";

					tos_count_tFileInputDelimited_1++;

					/**
					 * [tFileInputDelimited_1 main ] stop
					 */
					// Start of branch "row1"
					if (row1 != null) {

						/**
						 * [tOracleOutput_1 main ] start
						 */

						currentComponent = "tOracleOutput_1";

						whetherReject_tOracleOutput_1 = false;
						if (row1.NNE == null) {
							pstmt_tOracleOutput_1.setNull(1,
									java.sql.Types.VARCHAR);
						} else {
							pstmt_tOracleOutput_1.setString(1, row1.NNE);
						}

						if (row1.ADECOD == null) {
							pstmt_tOracleOutput_1.setNull(2,
									java.sql.Types.VARCHAR);
						} else {
							pstmt_tOracleOutput_1.setString(2, row1.ADECOD);
						}

						try {
							insertedCount_tOracleOutput_1 = insertedCount_tOracleOutput_1
									+ pstmt_tOracleOutput_1.executeUpdate();
							nb_line_tOracleOutput_1++;
						} catch (Exception e) {
							whetherReject_tOracleOutput_1 = true;
							System.err.print(e.getMessage());
						}

						if (!whetherReject_tOracleOutput_1) {
						}
						if (batchSize_tOracleOutput_1 <= batchSizeCounter_tOracleOutput_1) {

						}

						tos_count_tOracleOutput_1++;

						/**
						 * [tOracleOutput_1 main ] stop
						 */
					} // End of branch "row1"

					/**
					 * [tFileInputDelimited_1 end ] start
					 */

					currentComponent = "tFileInputDelimited_1";

					nb_line_tFileInputDelimited_1++;
				}
				if (!(filename_tFileInputDelimited_1 instanceof java.io.InputStream)) {
					csvReadertFileInputDelimited_1.close();
				}
				globalMap.put("tFileInputDelimited_1_NB_LINE",
						nb_line_tFileInputDelimited_1);

				ok_Hash.put("tFileInputDelimited_1", true);
				end_Hash.put("tFileInputDelimited_1", System
						.currentTimeMillis());

				/**
				 * [tFileInputDelimited_1 end ] stop
				 */

				/**
				 * [tOracleOutput_1 end ] start
				 */

				currentComponent = "tOracleOutput_1";

				if (pstmt_tOracleOutput_1 != null) {
					pstmt_tOracleOutput_1.close();
				}

				nb_line_deleted_tOracleOutput_1 = nb_line_deleted_tOracleOutput_1
						+ deletedCount_tOracleOutput_1;
				nb_line_update_tOracleOutput_1 = nb_line_update_tOracleOutput_1
						+ updatedCount_tOracleOutput_1;
				nb_line_inserted_tOracleOutput_1 = nb_line_inserted_tOracleOutput_1
						+ insertedCount_tOracleOutput_1;

				globalMap.put("tOracleOutput_1_NB_LINE",
						nb_line_tOracleOutput_1);
				globalMap.put("tOracleOutput_1_NB_LINE_UPDATED",
						nb_line_update_tOracleOutput_1);
				globalMap.put("tOracleOutput_1_NB_LINE_INSERTED",
						nb_line_inserted_tOracleOutput_1);
				globalMap.put("tOracleOutput_1_NB_LINE_DELETED",
						nb_line_deleted_tOracleOutput_1);

				ok_Hash.put("tOracleOutput_1", true);
				end_Hash.put("tOracleOutput_1", System.currentTimeMillis());

				tOracleCommit_1Process(globalMap);

				/**
				 * [tOracleOutput_1 end ] stop
				 */

				globalResumeTicket = true;

			}// end the resume

		} catch (Exception e) {

			throw new TalendException(e, currentComponent, globalMap);

		}

		globalMap.put("tFileInputDelimited_1_SUBPROCESS_STATE", 1);
	}

	public void tOracleCommit_1Process(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("tOracleCommit_1_SUBPROCESS_STATE", 0);

		String currentComponent = "";

		try {

			String currentMethodName = new Exception().getStackTrace()[0]
					.getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume

				/**
				 * [tOracleCommit_1 begin ] start
				 */

				ok_Hash.put("tOracleCommit_1", false);
				start_Hash.put("tOracleCommit_1", System.currentTimeMillis());
				currentComponent = "tOracleCommit_1";

				int tos_count_tOracleCommit_1 = 0;

				/**
				 * [tOracleCommit_1 begin ] stop
				 */
				/**
				 * [tOracleCommit_1 main ] start
				 */

				currentComponent = "tOracleCommit_1";

				java.sql.Connection conn_tOracleCommit_1 = (java.sql.Connection) globalMap
						.get("conn_tOracleConnection_1");
				if (conn_tOracleCommit_1 != null
						&& !conn_tOracleCommit_1.isClosed()) {
					conn_tOracleCommit_1.commit();
					conn_tOracleCommit_1.close();
				}

				tos_count_tOracleCommit_1++;

				/**
				 * [tOracleCommit_1 main ] stop
				 */
				/**
				 * [tOracleCommit_1 end ] start
				 */

				currentComponent = "tOracleCommit_1";

				ok_Hash.put("tOracleCommit_1", true);
				end_Hash.put("tOracleCommit_1", System.currentTimeMillis());

				/**
				 * [tOracleCommit_1 end ] stop
				 */

				globalResumeTicket = true;

			}// end the resume

		} catch (Exception e) {

			throw new TalendException(e, currentComponent, globalMap);

		}

		globalMap.put("tOracleCommit_1_SUBPROCESS_STATE", 1);
	}

	public static class row_talendLogs_LOGSStruct implements
			routines.system.IPersistableRow<row_talendLogs_LOGSStruct> {
		final static byte[] commonByteArrayLock = new byte[0];
		static byte[] commonByteArray = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public Integer priority;

		public Integer getPriority() {
			return this.priority;
		}

		public String type;

		public String getType() {
			return this.type;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Integer code;

		public Integer getCode() {
			return this.code;
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.moment = null;
					} else {
						this.moment = new Date(dis.readLong());
					}

					length = dis.readInt();
					if (length == -1) {
						this.pid = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.pid = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.root_pid = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.root_pid = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.father_pid = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.father_pid = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.project = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.project = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.job = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.job = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.context = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.context = new String(commonByteArray, 0, length);
					}

					length = dis.readByte();
					if (length == -1) {
						this.priority = null;
					} else {
						this.priority = dis.readInt();
					}

					length = dis.readInt();
					if (length == -1) {
						this.type = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.type = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.origin = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.origin = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.message = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.message = new String(commonByteArray, 0, length);
					}

					length = dis.readByte();
					if (length == -1) {
						this.code = null;
					} else {
						this.code = dis.readInt();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				if (this.moment == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.moment.getTime());
				}

				// String

				if (this.pid == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.pid.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.root_pid == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.root_pid.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.father_pid == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.father_pid.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.project == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.project.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.job == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.job.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.context == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.context.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// Integer

				if (this.priority == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeInt(this.priority);
				}

				// String

				if (this.type == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.type.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.origin == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.origin.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.message == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.message.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// Integer

				if (this.code == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeInt(this.code);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");

			sb.append("moment");
			sb.append("=");
			sb.append(String.valueOf(this.moment));

			sb.append(", ");

			sb.append("pid");
			sb.append("=");
			sb.append(String.valueOf(this.pid));

			sb.append(", ");

			sb.append("root_pid");
			sb.append("=");
			sb.append(String.valueOf(this.root_pid));

			sb.append(", ");

			sb.append("father_pid");
			sb.append("=");
			sb.append(String.valueOf(this.father_pid));

			sb.append(", ");

			sb.append("project");
			sb.append("=");
			sb.append(String.valueOf(this.project));

			sb.append(", ");

			sb.append("job");
			sb.append("=");
			sb.append(String.valueOf(this.job));

			sb.append(", ");

			sb.append("context");
			sb.append("=");
			sb.append(String.valueOf(this.context));

			sb.append(", ");

			sb.append("priority");
			sb.append("=");
			sb.append(String.valueOf(this.priority));

			sb.append(", ");

			sb.append("type");
			sb.append("=");
			sb.append(String.valueOf(this.type));

			sb.append(", ");

			sb.append("origin");
			sb.append("=");
			sb.append(String.valueOf(this.origin));

			sb.append(", ");

			sb.append("message");
			sb.append("=");
			sb.append(String.valueOf(this.message));

			sb.append(", ");

			sb.append("code");
			sb.append("=");
			sb.append(String.valueOf(this.code));

			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendLogs_LOGSStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2
						.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void talendLogs_LOGSProcess(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 0);

		String currentComponent = "";

		try {

			String currentMethodName = new Exception().getStackTrace()[0]
					.getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume

				row_talendLogs_LOGSStruct row_talendLogs_LOGS = new row_talendLogs_LOGSStruct();

				/**
				 * [talendLogs_FILE begin ] start
				 */

				ok_Hash.put("talendLogs_FILE", false);
				start_Hash.put("talendLogs_FILE", System.currentTimeMillis());
				currentComponent = "talendLogs_FILE";

				int tos_count_talendLogs_FILE = 0;

				String fileName_talendLogs_FILE = (new java.io.File(
						context.ENVIRONNEMENT_repertoireInstallation + "/"
								+ context.ENVIRONNEMENT_repertoireLogs + "/"
								+ context.INTERFACE_name + "/" + "/"
								+ context.INTERFACE_name + "_"
								+ context.INTERFACE_pckgName + "_"
								+ context.INTERFACE_dateDebut + "_" + rootPid
								+ "_log.log")).getAbsolutePath().replace("\\",
						"/");
				String fullName_talendLogs_FILE = null;
				String extension_talendLogs_FILE = null;
				String directory_talendLogs_FILE = null;
				if ((fileName_talendLogs_FILE.indexOf("/") != -1)) {
					if (fileName_talendLogs_FILE.lastIndexOf(".") < fileName_talendLogs_FILE
							.lastIndexOf("/")) {
						fullName_talendLogs_FILE = fileName_talendLogs_FILE;
						extension_talendLogs_FILE = "";
					} else {
						fullName_talendLogs_FILE = fileName_talendLogs_FILE
								.substring(0, fileName_talendLogs_FILE
										.lastIndexOf("."));
						extension_talendLogs_FILE = fileName_talendLogs_FILE
								.substring(fileName_talendLogs_FILE
										.lastIndexOf("."));
					}
					directory_talendLogs_FILE = fileName_talendLogs_FILE
							.substring(0, fileName_talendLogs_FILE
									.lastIndexOf("/"));
				} else {
					if (fileName_talendLogs_FILE.lastIndexOf(".") != -1) {
						fullName_talendLogs_FILE = fileName_talendLogs_FILE
								.substring(0, fileName_talendLogs_FILE
										.lastIndexOf("."));
						extension_talendLogs_FILE = fileName_talendLogs_FILE
								.substring(fileName_talendLogs_FILE
										.lastIndexOf("."));
					} else {
						fullName_talendLogs_FILE = fileName_talendLogs_FILE;
						extension_talendLogs_FILE = "";
					}
					directory_talendLogs_FILE = "";
				}

				int nb_line_talendLogs_FILE = 0;
				int splitEvery_talendLogs_FILE = 1000;
				int splitedFileNo_talendLogs_FILE = 0;
				int currentRow_talendLogs_FILE = 0;

				final String OUT_DELIM_talendLogs_FILE = /**
				 * Start field
				 * talendLogs_FILE:FIELDSEPARATOR
				 */
				";"/** End field talendLogs_FILE:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_talendLogs_FILE = /**
				 * Start field
				 * talendLogs_FILE:ROWSEPARATOR
				 */
				"\n"/** End field talendLogs_FILE:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_talendLogs_FILE != null
						&& directory_talendLogs_FILE.trim().length() != 0) {
					java.io.File dir_talendLogs_FILE = new java.io.File(
							directory_talendLogs_FILE);
					if (!dir_talendLogs_FILE.exists()) {
						dir_talendLogs_FILE.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtalendLogs_FILE = new java.io.BufferedWriter(
						new java.io.OutputStreamWriter(
								new java.io.FileOutputStream(
										fileName_talendLogs_FILE, true),
								"ISO-8859-15"));
				java.io.File filetalendLogs_FILE = new java.io.File(
						fileName_talendLogs_FILE);

				/**
				 * [talendLogs_FILE begin ] stop
				 */

				/**
				 * [talendLogs_LOGS begin ] start
				 */

				ok_Hash.put("talendLogs_LOGS", false);
				start_Hash.put("talendLogs_LOGS", System.currentTimeMillis());
				currentComponent = "talendLogs_LOGS";

				int tos_count_talendLogs_LOGS = 0;

				for (LogCatcherUtils.LogCatcherMessage lcm : talendLogs_LOGS
						.getMessages()) {
					row_talendLogs_LOGS.type = lcm.getType();
					row_talendLogs_LOGS.origin = (lcm.getOrigin() == null
							|| lcm.getOrigin().length() < 1 ? null : lcm
							.getOrigin());
					row_talendLogs_LOGS.priority = lcm.getPriority();
					row_talendLogs_LOGS.message = lcm.getMessage();
					row_talendLogs_LOGS.code = lcm.getCode();

					row_talendLogs_LOGS.moment = java.util.Calendar
							.getInstance().getTime();

					row_talendLogs_LOGS.pid = pid;
					row_talendLogs_LOGS.root_pid = rootPid;
					row_talendLogs_LOGS.father_pid = fatherPid;

					row_talendLogs_LOGS.project = projectName;
					row_talendLogs_LOGS.job = jobName;
					row_talendLogs_LOGS.context = contextStr;

					/**
					 * [talendLogs_LOGS begin ] stop
					 */
					/**
					 * [talendLogs_LOGS main ] start
					 */

					currentComponent = "talendLogs_LOGS";

					tos_count_talendLogs_LOGS++;

					/**
					 * [talendLogs_LOGS main ] stop
					 */

					/**
					 * [talendLogs_FILE main ] start
					 */

					currentComponent = "talendLogs_FILE";

					StringBuilder sb_talendLogs_FILE = new StringBuilder();

					if (row_talendLogs_LOGS.moment != null) {

						sb_talendLogs_FILE.append(

						FormatterUtils.format_Date(row_talendLogs_LOGS.moment,
								"yyyy-MM-dd HH:mm:ss")

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.pid != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.pid

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.root_pid != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.root_pid

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.father_pid != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.father_pid

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.project != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.project

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.job != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.job

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.context != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.context

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.priority != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.priority

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.type != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.type

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.origin != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.origin

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.message != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.message

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_talendLogs_FILE);

					if (row_talendLogs_LOGS.code != null) {

						sb_talendLogs_FILE.append(

						row_talendLogs_LOGS.code

						);

					}

					sb_talendLogs_FILE.append(OUT_DELIM_ROWSEP_talendLogs_FILE);

					nb_line_talendLogs_FILE++;

					outtalendLogs_FILE.write(sb_talendLogs_FILE.toString());

					tos_count_talendLogs_FILE++;

					/**
					 * [talendLogs_FILE main ] stop
					 */

					/**
					 * [talendLogs_LOGS end ] start
					 */

					currentComponent = "talendLogs_LOGS";

				}

				ok_Hash.put("talendLogs_LOGS", true);
				end_Hash.put("talendLogs_LOGS", System.currentTimeMillis());

				/**
				 * [talendLogs_LOGS end ] stop
				 */

				/**
				 * [talendLogs_FILE end ] start
				 */

				currentComponent = "talendLogs_FILE";

				outtalendLogs_FILE.close();
				globalMap.put("talendLogs_FILE_NB_LINE",
						nb_line_talendLogs_FILE);

				ok_Hash.put("talendLogs_FILE", true);
				end_Hash.put("talendLogs_FILE", System.currentTimeMillis());

				/**
				 * [talendLogs_FILE end ] stop
				 */

				globalResumeTicket = true;

			}// end the resume

		} catch (Exception e) {

			throw new TalendException(e, currentComponent, globalMap);

		}

		globalMap.put("talendLogs_LOGS_SUBPROCESS_STATE", 1);
	}

	public static class row_talendStats_STATSStruct implements
			routines.system.IPersistableRow<row_talendStats_STATSStruct> {
		final static byte[] commonByteArrayLock = new byte[0];
		static byte[] commonByteArray = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String message_type;

		public String getMessage_type() {
			return this.message_type;
		}

		public String message;

		public String getMessage() {
			return this.message;
		}

		public Long duration;

		public Long getDuration() {
			return this.duration;
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.moment = null;
					} else {
						this.moment = new Date(dis.readLong());
					}

					length = dis.readInt();
					if (length == -1) {
						this.pid = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.pid = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.father_pid = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.father_pid = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.root_pid = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.root_pid = new String(commonByteArray, 0, length);
					}

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					length = dis.readInt();
					if (length == -1) {
						this.project = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.project = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.job = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.job = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.job_repository_id = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.job_repository_id = new String(commonByteArray, 0,
								length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.job_version = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.job_version = new String(commonByteArray, 0,
								length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.context = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.context = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.origin = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.origin = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.message_type = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.message_type = new String(commonByteArray, 0,
								length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.message = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.message = new String(commonByteArray, 0, length);
					}

					length = dis.readByte();
					if (length == -1) {
						this.duration = null;
					} else {
						this.duration = dis.readLong();
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				if (this.moment == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.moment.getTime());
				}

				// String

				if (this.pid == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.pid.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.father_pid == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.father_pid.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.root_pid == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.root_pid.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				if (this.project == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.project.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.job == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.job.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.job_repository_id == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.job_repository_id.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.job_version == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.job_version.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.context == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.context.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.origin == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.origin.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.message_type == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.message_type.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.message == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.message.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// Long

				if (this.duration == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.duration);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");

			sb.append("moment");
			sb.append("=");
			sb.append(String.valueOf(this.moment));

			sb.append(", ");

			sb.append("pid");
			sb.append("=");
			sb.append(String.valueOf(this.pid));

			sb.append(", ");

			sb.append("father_pid");
			sb.append("=");
			sb.append(String.valueOf(this.father_pid));

			sb.append(", ");

			sb.append("root_pid");
			sb.append("=");
			sb.append(String.valueOf(this.root_pid));

			sb.append(", ");

			sb.append("system_pid");
			sb.append("=");
			sb.append(String.valueOf(this.system_pid));

			sb.append(", ");

			sb.append("project");
			sb.append("=");
			sb.append(String.valueOf(this.project));

			sb.append(", ");

			sb.append("job");
			sb.append("=");
			sb.append(String.valueOf(this.job));

			sb.append(", ");

			sb.append("job_repository_id");
			sb.append("=");
			sb.append(String.valueOf(this.job_repository_id));

			sb.append(", ");

			sb.append("job_version");
			sb.append("=");
			sb.append(String.valueOf(this.job_version));

			sb.append(", ");

			sb.append("context");
			sb.append("=");
			sb.append(String.valueOf(this.context));

			sb.append(", ");

			sb.append("origin");
			sb.append("=");
			sb.append(String.valueOf(this.origin));

			sb.append(", ");

			sb.append("message_type");
			sb.append("=");
			sb.append(String.valueOf(this.message_type));

			sb.append(", ");

			sb.append("message");
			sb.append("=");
			sb.append(String.valueOf(this.message));

			sb.append(", ");

			sb.append("duration");
			sb.append("=");
			sb.append(String.valueOf(this.duration));

			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendStats_STATSStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2
						.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void talendStats_STATSProcess(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 0);

		String currentComponent = "";

		try {

			String currentMethodName = new Exception().getStackTrace()[0]
					.getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume

				row_talendStats_STATSStruct row_talendStats_STATS = new row_talendStats_STATSStruct();

				/**
				 * [talendStats_FILE begin ] start
				 */

				ok_Hash.put("talendStats_FILE", false);
				start_Hash.put("talendStats_FILE", System.currentTimeMillis());
				currentComponent = "talendStats_FILE";

				int tos_count_talendStats_FILE = 0;

				String fileName_talendStats_FILE = (new java.io.File(
						context.ENVIRONNEMENT_repertoireInstallation + "/"
								+ context.ENVIRONNEMENT_repertoireLogs + "/"
								+ context.INTERFACE_name + "/" + "/"
								+ context.INTERFACE_name + "_"
								+ context.INTERFACE_pckgName + "_"
								+ context.INTERFACE_dateDebut + "_" + rootPid
								+ "_stat.log")).getAbsolutePath().replace("\\",
						"/");
				String fullName_talendStats_FILE = null;
				String extension_talendStats_FILE = null;
				String directory_talendStats_FILE = null;
				if ((fileName_talendStats_FILE.indexOf("/") != -1)) {
					if (fileName_talendStats_FILE.lastIndexOf(".") < fileName_talendStats_FILE
							.lastIndexOf("/")) {
						fullName_talendStats_FILE = fileName_talendStats_FILE;
						extension_talendStats_FILE = "";
					} else {
						fullName_talendStats_FILE = fileName_talendStats_FILE
								.substring(0, fileName_talendStats_FILE
										.lastIndexOf("."));
						extension_talendStats_FILE = fileName_talendStats_FILE
								.substring(fileName_talendStats_FILE
										.lastIndexOf("."));
					}
					directory_talendStats_FILE = fileName_talendStats_FILE
							.substring(0, fileName_talendStats_FILE
									.lastIndexOf("/"));
				} else {
					if (fileName_talendStats_FILE.lastIndexOf(".") != -1) {
						fullName_talendStats_FILE = fileName_talendStats_FILE
								.substring(0, fileName_talendStats_FILE
										.lastIndexOf("."));
						extension_talendStats_FILE = fileName_talendStats_FILE
								.substring(fileName_talendStats_FILE
										.lastIndexOf("."));
					} else {
						fullName_talendStats_FILE = fileName_talendStats_FILE;
						extension_talendStats_FILE = "";
					}
					directory_talendStats_FILE = "";
				}

				int nb_line_talendStats_FILE = 0;
				int splitEvery_talendStats_FILE = 1000;
				int splitedFileNo_talendStats_FILE = 0;
				int currentRow_talendStats_FILE = 0;

				final String OUT_DELIM_talendStats_FILE = /**
				 * Start field
				 * talendStats_FILE:FIELDSEPARATOR
				 */
				";"/** End field talendStats_FILE:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_talendStats_FILE = /**
				 * Start field
				 * talendStats_FILE:ROWSEPARATOR
				 */
				"\n"/** End field talendStats_FILE:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_talendStats_FILE != null
						&& directory_talendStats_FILE.trim().length() != 0) {
					java.io.File dir_talendStats_FILE = new java.io.File(
							directory_talendStats_FILE);
					if (!dir_talendStats_FILE.exists()) {
						dir_talendStats_FILE.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtalendStats_FILE = new java.io.BufferedWriter(
						new java.io.OutputStreamWriter(
								new java.io.FileOutputStream(
										fileName_talendStats_FILE, true),
								"ISO-8859-15"));
				java.io.File filetalendStats_FILE = new java.io.File(
						fileName_talendStats_FILE);

				/**
				 * [talendStats_FILE begin ] stop
				 */

				/**
				 * [talendStats_STATS begin ] start
				 */

				ok_Hash.put("talendStats_STATS", false);
				start_Hash.put("talendStats_STATS", System.currentTimeMillis());
				currentComponent = "talendStats_STATS";

				int tos_count_talendStats_STATS = 0;

				for (StatCatcherUtils.StatCatcherMessage scm : talendStats_STATS
						.getMessages()) {
					row_talendStats_STATS.pid = pid;
					row_talendStats_STATS.root_pid = rootPid;
					row_talendStats_STATS.father_pid = fatherPid;
					row_talendStats_STATS.project = projectName;
					row_talendStats_STATS.job = jobName;
					row_talendStats_STATS.context = contextStr;
					row_talendStats_STATS.origin = (scm.getOrigin() == null
							|| scm.getOrigin().length() < 1 ? null : scm
							.getOrigin());
					row_talendStats_STATS.message = scm.getMessage();
					row_talendStats_STATS.duration = scm.getDuration();
					row_talendStats_STATS.moment = scm.getMoment();
					row_talendStats_STATS.message_type = scm.getMessageType();
					row_talendStats_STATS.job_version = scm.getJobVersion();
					row_talendStats_STATS.job_repository_id = scm.getJobId();
					row_talendStats_STATS.system_pid = scm.getSystemPid();

					/**
					 * [talendStats_STATS begin ] stop
					 */
					/**
					 * [talendStats_STATS main ] start
					 */

					currentComponent = "talendStats_STATS";

					tos_count_talendStats_STATS++;

					/**
					 * [talendStats_STATS main ] stop
					 */

					/**
					 * [talendStats_FILE main ] start
					 */

					currentComponent = "talendStats_FILE";

					StringBuilder sb_talendStats_FILE = new StringBuilder();

					if (row_talendStats_STATS.moment != null) {

						sb_talendStats_FILE.append(

						FormatterUtils.format_Date(
								row_talendStats_STATS.moment,
								"yyyy-MM-dd HH:mm:ss")

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.pid != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.pid

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.father_pid != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.father_pid

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.root_pid != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.root_pid

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.system_pid != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.system_pid

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.project != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.project

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.job != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.job

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.job_repository_id != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.job_repository_id

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.job_version != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.job_version

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.context != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.context

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.origin != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.origin

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.message_type != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.message_type

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.message != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.message

						);

					}

					sb_talendStats_FILE.append(OUT_DELIM_talendStats_FILE);

					if (row_talendStats_STATS.duration != null) {

						sb_talendStats_FILE.append(

						row_talendStats_STATS.duration

						);

					}

					sb_talendStats_FILE
							.append(OUT_DELIM_ROWSEP_talendStats_FILE);

					nb_line_talendStats_FILE++;

					outtalendStats_FILE.write(sb_talendStats_FILE.toString());

					tos_count_talendStats_FILE++;

					/**
					 * [talendStats_FILE main ] stop
					 */

					/**
					 * [talendStats_STATS end ] start
					 */

					currentComponent = "talendStats_STATS";

				}

				ok_Hash.put("talendStats_STATS", true);
				end_Hash.put("talendStats_STATS", System.currentTimeMillis());

				/**
				 * [talendStats_STATS end ] stop
				 */

				/**
				 * [talendStats_FILE end ] start
				 */

				currentComponent = "talendStats_FILE";

				outtalendStats_FILE.close();
				globalMap.put("talendStats_FILE_NB_LINE",
						nb_line_talendStats_FILE);

				ok_Hash.put("talendStats_FILE", true);
				end_Hash.put("talendStats_FILE", System.currentTimeMillis());

				/**
				 * [talendStats_FILE end ] stop
				 */

				globalResumeTicket = true;

			}// end the resume

		} catch (Exception e) {

			throw new TalendException(e, currentComponent, globalMap);

		}

		globalMap.put("talendStats_STATS_SUBPROCESS_STATE", 1);
	}

	public static class row_talendMeter_METTERStruct implements
			routines.system.IPersistableRow<row_talendMeter_METTERStruct> {
		final static byte[] commonByteArrayLock = new byte[0];
		static byte[] commonByteArray = new byte[0];

		public java.util.Date moment;

		public java.util.Date getMoment() {
			return this.moment;
		}

		public String pid;

		public String getPid() {
			return this.pid;
		}

		public String father_pid;

		public String getFather_pid() {
			return this.father_pid;
		}

		public String root_pid;

		public String getRoot_pid() {
			return this.root_pid;
		}

		public Long system_pid;

		public Long getSystem_pid() {
			return this.system_pid;
		}

		public String project;

		public String getProject() {
			return this.project;
		}

		public String job;

		public String getJob() {
			return this.job;
		}

		public String job_repository_id;

		public String getJob_repository_id() {
			return this.job_repository_id;
		}

		public String job_version;

		public String getJob_version() {
			return this.job_version;
		}

		public String context;

		public String getContext() {
			return this.context;
		}

		public String origin;

		public String getOrigin() {
			return this.origin;
		}

		public String label;

		public String getLabel() {
			return this.label;
		}

		public Integer count;

		public Integer getCount() {
			return this.count;
		}

		public Integer reference;

		public Integer getReference() {
			return this.reference;
		}

		public String thresholds;

		public String getThresholds() {
			return this.thresholds;
		}

		public void readData(ObjectInputStream dis) {

			synchronized (commonByteArrayLock) {

				try {

					int length = 0;

					length = dis.readByte();
					if (length == -1) {
						this.moment = null;
					} else {
						this.moment = new Date(dis.readLong());
					}

					length = dis.readInt();
					if (length == -1) {
						this.pid = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.pid = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.father_pid = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.father_pid = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.root_pid = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.root_pid = new String(commonByteArray, 0, length);
					}

					length = dis.readByte();
					if (length == -1) {
						this.system_pid = null;
					} else {
						this.system_pid = dis.readLong();
					}

					length = dis.readInt();
					if (length == -1) {
						this.project = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.project = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.job = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.job = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.job_repository_id = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.job_repository_id = new String(commonByteArray, 0,
								length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.job_version = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.job_version = new String(commonByteArray, 0,
								length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.context = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.context = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.origin = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.origin = new String(commonByteArray, 0, length);
					}

					length = dis.readInt();
					if (length == -1) {
						this.label = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.label = new String(commonByteArray, 0, length);
					}

					length = dis.readByte();
					if (length == -1) {
						this.count = null;
					} else {
						this.count = dis.readInt();
					}

					length = dis.readByte();
					if (length == -1) {
						this.reference = null;
					} else {
						this.reference = dis.readInt();
					}

					length = dis.readInt();
					if (length == -1) {
						this.thresholds = null;
					} else {
						if (length > commonByteArray.length) {
							if (length < 1024 && commonByteArray.length == 0) {
								commonByteArray = new byte[1024];
							} else {
								commonByteArray = new byte[2 * length];
							}
						}
						dis.readFully(commonByteArray, 0, length);
						this.thresholds = new String(commonByteArray, 0, length);
					}

				} catch (IOException e) {
					throw new RuntimeException(e);

				}

			}

		}

		public void writeData(ObjectOutputStream dos) {
			try {

				// java.util.Date

				if (this.moment == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.moment.getTime());
				}

				// String

				if (this.pid == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.pid.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.father_pid == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.father_pid.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.root_pid == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.root_pid.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// Long

				if (this.system_pid == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeLong(this.system_pid);
				}

				// String

				if (this.project == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.project.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.job == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.job.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.job_repository_id == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.job_repository_id.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.job_version == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.job_version.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.context == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.context.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.origin == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.origin.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// String

				if (this.label == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.label.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

				// Integer

				if (this.count == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeInt(this.count);
				}

				// Integer

				if (this.reference == null) {
					dos.writeByte(-1);
				} else {
					dos.writeByte(0);
					dos.writeInt(this.reference);
				}

				// String

				if (this.thresholds == null) {
					dos.writeInt(-1);
				} else {
					byte[] byteArray = this.thresholds.getBytes();
					dos.writeInt(byteArray.length);
					dos.write(byteArray);
				}

			} catch (IOException e) {
				throw new RuntimeException(e);
			}

		}

		public String toString() {

			StringBuilder sb = new StringBuilder();
			sb.append(super.toString());
			sb.append("[");

			sb.append("moment");
			sb.append("=");
			sb.append(String.valueOf(this.moment));

			sb.append(", ");

			sb.append("pid");
			sb.append("=");
			sb.append(String.valueOf(this.pid));

			sb.append(", ");

			sb.append("father_pid");
			sb.append("=");
			sb.append(String.valueOf(this.father_pid));

			sb.append(", ");

			sb.append("root_pid");
			sb.append("=");
			sb.append(String.valueOf(this.root_pid));

			sb.append(", ");

			sb.append("system_pid");
			sb.append("=");
			sb.append(String.valueOf(this.system_pid));

			sb.append(", ");

			sb.append("project");
			sb.append("=");
			sb.append(String.valueOf(this.project));

			sb.append(", ");

			sb.append("job");
			sb.append("=");
			sb.append(String.valueOf(this.job));

			sb.append(", ");

			sb.append("job_repository_id");
			sb.append("=");
			sb.append(String.valueOf(this.job_repository_id));

			sb.append(", ");

			sb.append("job_version");
			sb.append("=");
			sb.append(String.valueOf(this.job_version));

			sb.append(", ");

			sb.append("context");
			sb.append("=");
			sb.append(String.valueOf(this.context));

			sb.append(", ");

			sb.append("origin");
			sb.append("=");
			sb.append(String.valueOf(this.origin));

			sb.append(", ");

			sb.append("label");
			sb.append("=");
			sb.append(String.valueOf(this.label));

			sb.append(", ");

			sb.append("count");
			sb.append("=");
			sb.append(String.valueOf(this.count));

			sb.append(", ");

			sb.append("reference");
			sb.append("=");
			sb.append(String.valueOf(this.reference));

			sb.append(", ");

			sb.append("thresholds");
			sb.append("=");
			sb.append(String.valueOf(this.thresholds));

			sb.append("]");

			return sb.toString();
		}

		/**
		 * Compare keys
		 */
		public int compareTo(row_talendMeter_METTERStruct other) {

			int returnValue = -1;

			return returnValue;
		}

		private int checkNullsAndCompare(Object object1, Object object2) {
			int returnValue = 0;
			if (object1 instanceof Comparable && object2 instanceof Comparable) {
				returnValue = ((Comparable) object1).compareTo(object2);
			} else if (object1 != null && object2 != null) {
				returnValue = compareStrings(object1.toString(), object2
						.toString());
			} else if (object1 == null && object2 != null) {
				returnValue = 1;
			} else if (object1 != null && object2 == null) {
				returnValue = -1;
			} else {
				returnValue = 0;
			}

			return returnValue;
		}

		private int compareStrings(String string1, String string2) {
			return string1.compareTo(string2);
		}

	}

	public void talendMeter_METTERProcess(
			final java.util.Map<String, Object> globalMap)
			throws TalendException {
		globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 0);

		String currentComponent = "";

		try {

			String currentMethodName = new Exception().getStackTrace()[0]
					.getMethodName();
			boolean resumeIt = currentMethodName.equals(resumeEntryMethodName);
			if (resumeEntryMethodName == null || resumeIt || globalResumeTicket) {// start
																					// the
																					// resume

				row_talendMeter_METTERStruct row_talendMeter_METTER = new row_talendMeter_METTERStruct();

				/**
				 * [talendMeter_FILE begin ] start
				 */

				ok_Hash.put("talendMeter_FILE", false);
				start_Hash.put("talendMeter_FILE", System.currentTimeMillis());
				currentComponent = "talendMeter_FILE";

				int tos_count_talendMeter_FILE = 0;

				String fileName_talendMeter_FILE = (new java.io.File(
						context.ENVIRONNEMENT_repertoireInstallation + "/"
								+ context.ENVIRONNEMENT_repertoireLogs + "/"
								+ context.INTERFACE_name + "/" + "/"
								+ context.INTERFACE_name + "_"
								+ context.INTERFACE_pckgName + "_"
								+ context.INTERFACE_dateDebut + "_" + rootPid
								+ "_meter.log")).getAbsolutePath().replace(
						"\\", "/");
				String fullName_talendMeter_FILE = null;
				String extension_talendMeter_FILE = null;
				String directory_talendMeter_FILE = null;
				if ((fileName_talendMeter_FILE.indexOf("/") != -1)) {
					if (fileName_talendMeter_FILE.lastIndexOf(".") < fileName_talendMeter_FILE
							.lastIndexOf("/")) {
						fullName_talendMeter_FILE = fileName_talendMeter_FILE;
						extension_talendMeter_FILE = "";
					} else {
						fullName_talendMeter_FILE = fileName_talendMeter_FILE
								.substring(0, fileName_talendMeter_FILE
										.lastIndexOf("."));
						extension_talendMeter_FILE = fileName_talendMeter_FILE
								.substring(fileName_talendMeter_FILE
										.lastIndexOf("."));
					}
					directory_talendMeter_FILE = fileName_talendMeter_FILE
							.substring(0, fileName_talendMeter_FILE
									.lastIndexOf("/"));
				} else {
					if (fileName_talendMeter_FILE.lastIndexOf(".") != -1) {
						fullName_talendMeter_FILE = fileName_talendMeter_FILE
								.substring(0, fileName_talendMeter_FILE
										.lastIndexOf("."));
						extension_talendMeter_FILE = fileName_talendMeter_FILE
								.substring(fileName_talendMeter_FILE
										.lastIndexOf("."));
					} else {
						fullName_talendMeter_FILE = fileName_talendMeter_FILE;
						extension_talendMeter_FILE = "";
					}
					directory_talendMeter_FILE = "";
				}

				int nb_line_talendMeter_FILE = 0;
				int splitEvery_talendMeter_FILE = 1000;
				int splitedFileNo_talendMeter_FILE = 0;
				int currentRow_talendMeter_FILE = 0;

				final String OUT_DELIM_talendMeter_FILE = /**
				 * Start field
				 * talendMeter_FILE:FIELDSEPARATOR
				 */
				";"/** End field talendMeter_FILE:FIELDSEPARATOR */
				;

				final String OUT_DELIM_ROWSEP_talendMeter_FILE = /**
				 * Start field
				 * talendMeter_FILE:ROWSEPARATOR
				 */
				"\n"/** End field talendMeter_FILE:ROWSEPARATOR */
				;

				// create directory only if not exists
				if (directory_talendMeter_FILE != null
						&& directory_talendMeter_FILE.trim().length() != 0) {
					java.io.File dir_talendMeter_FILE = new java.io.File(
							directory_talendMeter_FILE);
					if (!dir_talendMeter_FILE.exists()) {
						dir_talendMeter_FILE.mkdirs();
					}
				}

				// routines.system.Row
				java.io.Writer outtalendMeter_FILE = new java.io.BufferedWriter(
						new java.io.OutputStreamWriter(
								new java.io.FileOutputStream(
										fileName_talendMeter_FILE, true),
								"ISO-8859-15"));
				java.io.File filetalendMeter_FILE = new java.io.File(
						fileName_talendMeter_FILE);

				/**
				 * [talendMeter_FILE begin ] stop
				 */

				/**
				 * [talendMeter_METTER begin ] start
				 */

				ok_Hash.put("talendMeter_METTER", false);
				start_Hash
						.put("talendMeter_METTER", System.currentTimeMillis());
				currentComponent = "talendMeter_METTER";

				int tos_count_talendMeter_METTER = 0;

				for (MetterCatcherUtils.MetterCatcherMessage mcm : talendMeter_METTER
						.getMessages()) {
					row_talendMeter_METTER.pid = pid;
					row_talendMeter_METTER.root_pid = rootPid;
					row_talendMeter_METTER.father_pid = fatherPid;
					row_talendMeter_METTER.project = projectName;
					row_talendMeter_METTER.job = jobName;
					row_talendMeter_METTER.context = contextStr;
					row_talendMeter_METTER.origin = (mcm.getOrigin() == null
							|| mcm.getOrigin().length() < 1 ? null : mcm
							.getOrigin());
					row_talendMeter_METTER.moment = mcm.getMoment();
					row_talendMeter_METTER.job_version = mcm.getJobVersion();
					row_talendMeter_METTER.job_repository_id = mcm.getJobId();
					row_talendMeter_METTER.system_pid = mcm.getSystemPid();
					row_talendMeter_METTER.label = mcm.getLabel();
					row_talendMeter_METTER.count = mcm.getCount();
					row_talendMeter_METTER.reference = talendMeter_METTER
							.getConnLinesCount(mcm.getReferense() + "_count");
					row_talendMeter_METTER.thresholds = mcm.getThresholds();

					/**
					 * [talendMeter_METTER begin ] stop
					 */
					/**
					 * [talendMeter_METTER main ] start
					 */

					currentComponent = "talendMeter_METTER";

					tos_count_talendMeter_METTER++;

					/**
					 * [talendMeter_METTER main ] stop
					 */

					/**
					 * [talendMeter_FILE main ] start
					 */

					currentComponent = "talendMeter_FILE";

					StringBuilder sb_talendMeter_FILE = new StringBuilder();

					if (row_talendMeter_METTER.moment != null) {

						sb_talendMeter_FILE.append(

						FormatterUtils.format_Date(
								row_talendMeter_METTER.moment,
								"yyyy-MM-dd HH:mm:ss")

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.pid != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.pid

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.father_pid != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.father_pid

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.root_pid != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.root_pid

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.system_pid != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.system_pid

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.project != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.project

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.job != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.job

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.job_repository_id != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.job_repository_id

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.job_version != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.job_version

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.context != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.context

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.origin != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.origin

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.label != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.label

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.count != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.count

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.reference != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.reference

						);

					}

					sb_talendMeter_FILE.append(OUT_DELIM_talendMeter_FILE);

					if (row_talendMeter_METTER.thresholds != null) {

						sb_talendMeter_FILE.append(

						row_talendMeter_METTER.thresholds

						);

					}

					sb_talendMeter_FILE
							.append(OUT_DELIM_ROWSEP_talendMeter_FILE);

					nb_line_talendMeter_FILE++;

					outtalendMeter_FILE.write(sb_talendMeter_FILE.toString());

					tos_count_talendMeter_FILE++;

					/**
					 * [talendMeter_FILE main ] stop
					 */

					/**
					 * [talendMeter_METTER end ] start
					 */

					currentComponent = "talendMeter_METTER";

				}

				ok_Hash.put("talendMeter_METTER", true);
				end_Hash.put("talendMeter_METTER", System.currentTimeMillis());

				/**
				 * [talendMeter_METTER end ] stop
				 */

				/**
				 * [talendMeter_FILE end ] start
				 */

				currentComponent = "talendMeter_FILE";

				outtalendMeter_FILE.close();
				globalMap.put("talendMeter_FILE_NB_LINE",
						nb_line_talendMeter_FILE);

				ok_Hash.put("talendMeter_FILE", true);
				end_Hash.put("talendMeter_FILE", System.currentTimeMillis());

				/**
				 * [talendMeter_FILE end ] stop
				 */

				globalResumeTicket = true;

			}// end the resume

		} catch (Exception e) {

			throw new TalendException(e, currentComponent, globalMap);

		}

		globalMap.put("talendMeter_METTER_SUBPROCESS_STATE", 1);
	}

	public String resuming_logs_dir_path = null;
	public String resuming_checkpoint_path = null;
	public String parent_part_launcher = null;
	private String resumeEntryMethodName = null;
	private boolean globalResumeTicket = false;

	public boolean watch = false;
	public int portStats = 3334;
	public int portTraces = 4334;
	public String clientHost;
	public String defaultClientHost = "localhost";
	public String contextStr = "Default";
	public String pid = "0";
	public String rootPid = null;
	public String fatherPid = null;
	public long startTime = 0;
	public boolean isChildJob = false;

	private ThreadLocal threadLocal = new ThreadLocal();
	{
		java.util.Map threadRunResultMap = new java.util.HashMap();
		threadRunResultMap.put("errorCode", null);
		threadRunResultMap.put("status", "");
		threadLocal.set(threadRunResultMap);
	}

	private java.util.Properties context_param = new java.util.Properties();

	public String status = "";

	public static void main(String[] args) {
		final INS_CSV_IN_ORA INS_CSV_IN_ORAClass = new INS_CSV_IN_ORA();

		int exitCode = INS_CSV_IN_ORAClass.runJobInTOS(args);

		System.exit(exitCode);
	}

	public String[][] runJob(String[] args) {

		int exitCode = runJobInTOS(args);
		String[][] bufferValue = new String[][] { { Integer.toString(exitCode) } };

		return bufferValue;
	}

	public int runJobInTOS(String[] args) {

		String lastStr = "";
		for (String arg : args) {
			if (arg.equalsIgnoreCase("--context_param")) {
				lastStr = arg;
			} else if (lastStr.equals("")) {
				evalParam(arg);
			} else {
				evalParam(lastStr + " " + arg);
				lastStr = "";
			}
		}

		if (clientHost == null) {
			clientHost = defaultClientHost;
		}

		if (pid == null || "0".equals(pid)) {
			pid = TalendString.getAsciiRandomString(6);
		}

		if (rootPid == null) {
			rootPid = pid;
		}
		if (fatherPid == null) {
			fatherPid = pid;
		} else {
			isChildJob = true;
		}

		// Resume: init the resumeUtil
		resumeEntryMethodName = ResumeUtil
				.getResumeEntryMethodName(resuming_checkpoint_path);
		resumeUtil = new ResumeUtil(resuming_logs_dir_path, isChildJob, rootPid);
		resumeUtil.initCommonInfo(pid, rootPid, fatherPid, projectName,
				jobName, contextStr, jobVersion);

		// Resume: jobStart
		resumeUtil.addLog("JOB_STARTED", "JOB:" + jobName,
				parent_part_launcher, Thread.currentThread().getId() + "", "",
				"", "", "");

		try {
			java.io.InputStream inContext = INS_CSV_IN_ORA.class
					.getClassLoader()
					.getResourceAsStream(
							"prime/ins_csv_in_ora_0_1/contexts/Default.properties");
			if (inContext != null) {
				defaultProps.load(inContext);
				inContext.close();
				context = new ContextProperties(defaultProps);
			}

			if (contextStr.compareTo("Default") != 0) {
				inContext = INS_CSV_IN_ORA.class.getClassLoader()
						.getResourceAsStream(
								"prime/ins_csv_in_ora_0_1/contexts/"
										+ contextStr + ".properties");
				if (inContext != null) {
					context.load(inContext);
					inContext.close();
				}
			}

			if (!context_param.isEmpty()) {
				context.putAll(context_param);
			}

			context.ENVIRONNEMENT_dossierTmp = (String) context
					.getProperty("ENVIRONNEMENT_dossierTmp");

			context.ENVIRONNEMENT_repertoireGenerationRbm = (String) context
					.getProperty("ENVIRONNEMENT_repertoireGenerationRbm");

			context.ENVIRONNEMENT_repertoireInstallation = (String) context
					.getProperty("ENVIRONNEMENT_repertoireInstallation");

			context.ENVIRONNEMENT_repertoireLogs = (String) context
					.getProperty("ENVIRONNEMENT_repertoireLogs");

			context.ENVIRONNEMENT_repertoireStockageSource = (String) context
					.getProperty("ENVIRONNEMENT_repertoireStockageSource");

			context.INTERFACE_codeService = (String) context
					.getProperty("INTERFACE_codeService");

			context.INTERFACE_CODETG = (String) context
					.getProperty("INTERFACE_CODETG");

			context.INTERFACE_confFile = (String) context
					.getProperty("INTERFACE_confFile");

			context.INTERFACE_CORRES = (String) context
					.getProperty("INTERFACE_CORRES");

			context.INTERFACE_dateDebut = (String) context
					.getProperty("INTERFACE_dateDebut");

			context.INTERFACE_FILE = (String) context
					.getProperty("INTERFACE_FILE");

			context.INTERFACE_moisPaie = (String) context
					.getProperty("INTERFACE_moisPaie");

			context.INTERFACE_mv = (String) context.getProperty("INTERFACE_mv");

			context.INTERFACE_name = (String) context
					.getProperty("INTERFACE_name");

			context.INTERFACE_params = (String) context
					.getProperty("INTERFACE_params");

			context.INTERFACE_pckgName = (String) context
					.getProperty("INTERFACE_pckgName");

			context.INTERFACE_returnCode = (String) context
					.getProperty("INTERFACE_returnCode");

			context.INTERFACE_srcFileName = (String) context
					.getProperty("INTERFACE_srcFileName");

			context.REHUCIT_TAMPON_Login = (String) context
					.getProperty("REHUCIT_TAMPON_Login");

			context.REHUCIT_TAMPON_Password = (java.lang.String) context
					.getProperty("REHUCIT_TAMPON_Password");

			context.REHUCIT_TAMPON_Port = (String) context
					.getProperty("REHUCIT_TAMPON_Port");

			context.REHUCIT_TAMPON_Schema = (String) context
					.getProperty("REHUCIT_TAMPON_Schema");

			context.REHUCIT_TAMPON_Server = (String) context
					.getProperty("REHUCIT_TAMPON_Server");

			context.REHUCIT_TAMPON_Sid = (String) context
					.getProperty("REHUCIT_TAMPON_Sid");

		} catch (java.io.IOException ie) {
			System.err.println("Could not load context " + contextStr);
			ie.printStackTrace();
		}

		long startUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		long endUsedMemory = 0;
		long end = 0;

		startTime = System.currentTimeMillis();
		talendStats_STATS.addMessage("begin");

		this.globalResumeTicket = true;// to run tPreJob

		try {
			talendStats_STATSProcess(globalMap);
		} catch (Exception e) {
			e.printStackTrace();
		}

		this.globalResumeTicket = false;// to run others jobs

		try {
			errorCode = null;
			tOracleConnection_1Process(globalMap);
			status = "end";
		} catch (TalendException e_tOracleConnection_1) {
			status = "failure";
			e_tOracleConnection_1.printStackTrace();
			globalMap.put("tOracleConnection_1_SUBPROCESS_STATE", -1);

		} finally {
		}

		this.globalResumeTicket = true;// to run tPostJob

		end = System.currentTimeMillis();

		if (watch) {
			System.out.println((end - startTime) + " milliseconds");
		}

		endUsedMemory = Runtime.getRuntime().totalMemory()
				- Runtime.getRuntime().freeMemory();
		if (false) {
			System.out.println((endUsedMemory - startUsedMemory)
					+ " bytes memory increase when running : INS_CSV_IN_ORA");
		}
		talendStats_STATS.addMessage(status == "" ? "end" : status,
				(end - startTime));
		try {
			talendStats_STATSProcess(globalMap);
		} catch (Exception e) {
			e.printStackTrace();
		}

		resumeUtil.addLog("JOB_ENDED", "JOB:" + jobName, parent_part_launcher,
				Thread.currentThread().getId() + "", "", "", "", "");

		if (errorCode == null) {
			return status != null && status.equals("failure") ? 1 : 0;
		} else {
			return errorCode.intValue();
		}
	}

	private void evalParam(String arg) {
		if (arg.startsWith("--resuming_logs_dir_path")) {
			resuming_logs_dir_path = arg.substring(25);
		} else if (arg.startsWith("--resuming_checkpoint_path")) {
			resuming_checkpoint_path = arg.substring(27);
		} else if (arg.startsWith("--parent_part_launcher")) {
			parent_part_launcher = arg.substring(23);
		} else if (arg.startsWith("--watch")) {
			watch = true;
		} else if (arg.startsWith("--stat_port=")) {
			portStats = Integer.parseInt(arg.substring(12));
		} else if (arg.startsWith("--trace_port=")) {
			portTraces = Integer.parseInt(arg.substring(13));
		} else if (arg.startsWith("--client_host=")) {
			clientHost = arg.substring(14);
		} else if (arg.startsWith("--context=")) {
			contextStr = arg.substring(10);
		} else if (arg.startsWith("--father_pid=")) {
			fatherPid = arg.substring(13);
		} else if (arg.startsWith("--root_pid=")) {
			rootPid = arg.substring(11);
		} else if (arg.startsWith("--pid=")) {
			pid = arg.substring(6);
		} else if (arg.startsWith("--context_param")) {
			String keyValue = arg.substring(16);
			int index = -1;
			if (keyValue != null && (index = keyValue.indexOf('=')) > -1) {
				context_param.put(keyValue.substring(0, index), keyValue
						.substring(index + 1));
			}
		}

	}

	public Integer getErrorCode() {
		return errorCode;
	}

	public String getStatus() {
		return status;
	}

	ResumeUtil resumeUtil = null;
}
/************************************************************************************************
 * 128508 characters generated by Talend Integration Suite Team Edition on the
 * 22 juillet 2010 17:51:09 CEST
 ************************************************************************************************/
