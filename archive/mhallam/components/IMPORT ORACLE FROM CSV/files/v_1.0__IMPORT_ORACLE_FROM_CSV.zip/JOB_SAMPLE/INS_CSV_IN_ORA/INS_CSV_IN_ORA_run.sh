cd `dirname $0`
 ROOT_PATH=`pwd`
java -Xms256M -Xmx1024M -cp classpath.jar: prime.ins_csv_in_ora_0_1.INS_CSV_IN_ORA --context=Default $* 